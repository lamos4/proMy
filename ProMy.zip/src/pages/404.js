import React from 'react';


export default () => (
  <div>
    404
  </div>
);
